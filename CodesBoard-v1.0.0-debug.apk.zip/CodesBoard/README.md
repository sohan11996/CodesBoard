# Codes Board - Professional Programmer's Keyboard for Android

Codes Board is a high-performance, lightweight Android soft keyboard designed specifically for software developers, sysadmins, and terminal power users.

## Features
- **Tactile Chiclet Keycaps**: Engineered for high legibility, fast typing cadence, and ergonomic thumb reach.
- **Persistent Programmer Row**: Instant access to `Esc`, `Tab`, `Ctrl`, `Alt`, arrow navigation, and brackets.
- **Modifier Latching**: Real `Ctrl+C`, `Ctrl+V`, `Ctrl+Z`, `Ctrl+A`, and `Alt+F` dispatch to terminal applications (Termux, SSH, Neovim).
- **Direct Canvas Engine**: Zero-lag typing response with hardware-accelerated canvas rendering.
- **Zero Network Permissions**: 100% offline. Keystrokes, passwords, and private SSH keys never leave your phone.

## Build Requirements
- Android Studio Iguana or newer
- OpenJDK 17
- Android SDK 34 (Android 14)
- Minimum Android 8.0 (API 26)

## Quick Build Command
```bash
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## License
Apache License 2.0