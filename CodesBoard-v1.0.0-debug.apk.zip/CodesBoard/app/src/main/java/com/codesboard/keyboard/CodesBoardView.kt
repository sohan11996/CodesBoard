package com.codesboard.keyboard

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

/**
 * Codes Board: Custom hardware-accelerated Canvas View rendering
 * professional chiclet keycaps, active modifier latches, and haptic feedback.
 */
class CodesBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    interface OnKeyboardActionListener {
        fun onKey(keyCode: Int)
        fun onText(text: String)
    }

    private var actionListener: OnKeyboardActionListener? = null
    
    private var currentLayer: Layout.Layer = Layout.Layer.ALPHA
    private var isCtrl = false
    private var isAlt = false
    private var isShift = false
    private var isCaps = false

    // Professional Dark Theme Palette
    private val bgPaint = Paint().apply { color = Color.parseColor("#0F131A") }
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#222834") }
    private val keyHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#343D4E") }
    private val keySpecialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1A202C") }
    private val keyActivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#384252") }
    private val keyModifierLatched = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0284C7") }
    
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F1F5F9")
        textAlign = Paint.Align.CENTER
        textSize = 44f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }
    private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#94A3B8")
        textAlign = Paint.Align.RIGHT
        textSize = 24f
    }

    private var activeTouchKey: Layout.Key? = null
    private val keyBounds = mutableMapOf<Layout.Key, RectF>()

    fun setOnKeyboardActionListener(listener: OnKeyboardActionListener) {
        this.actionListener = listener
    }

    fun updateModifierStates(ctrl: Boolean, alt: Boolean, shift: Boolean, caps: Boolean) {
        this.isCtrl = ctrl
        this.isAlt = alt
        this.isShift = shift
        this.isCaps = caps
        invalidate()
    }

    fun setLayer(layer: Layout.Layer) {
        this.currentLayer = layer
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredHeight = (resources.displayMetrics.density * 280).toInt()
        val height = resolveSize(desiredHeight, heightMeasureSpec)
        val width = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(width, height)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeKeyBounds(w.toFloat(), h.toFloat())
    }

    private fun computeKeyBounds(width: Float, height: Float) {
        keyBounds.clear()
        val rows = Layout.getRows(currentLayer)
        val rowHeight = height / rows.size
        
        rows.forEachIndexed { rowIndex, row ->
            val top = rowIndex * rowHeight
            val bottom = top + rowHeight
            var left = 0f
            val totalWeight = row.keys.sumOf { it.weight.toDouble() }.toFloat()
            
            row.keys.forEach { key ->
                val keyWidth = (key.weight / totalWeight) * width
                val right = left + keyWidth
                // Key margin for chiclet feel
                keyBounds[key] = RectF(left + 3f, top + 3f, right - 3f, bottom - 3f)
                left = right
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        keyBounds.forEach { (key, rect) ->
            val isPressed = (key == activeTouchKey)
            val isModifierActive = when (key.code) {
                Layout.KEYCODE_CTRL -> isCtrl
                Layout.KEYCODE_ALT -> isAlt
                Layout.KEYCODE_SHIFT -> isShift || isCaps
                else -> false
            }

            val paint = when {
                isModifierActive -> keyModifierLatched
                isPressed -> keyActivePaint
                key.isSpecial -> keySpecialPaint
                else -> keyPaint
            }

            // Draw rounded tactile keycap
            canvas.drawRoundRect(rect, 12f, 12f, paint)

            // Draw key label
            val textY = rect.centerY() - ((textPaint.descent() + textPaint.ascent()) / 2)
            val displayLabel = if (isShift || isCaps) key.shiftLabel ?: key.label else key.label
            canvas.drawText(displayLabel, rect.centerX(), textY, textPaint)

            // Draw sublabel in top-right corner
            key.subLabel?.let { sub ->
                canvas.drawText(sub, rect.right - 8f, rect.top + 24f, subTextPaint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hitKey = findKeyAt(event.x, event.y)
                if (hitKey != null) {
                    activeTouchKey = hitKey
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    invalidate()
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                activeTouchKey?.let { key ->
                    dispatchKey(key)
                    activeTouchKey = null
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                activeTouchKey = null
                invalidate()
            }
        }
        return super.onTouchEvent(event)
    }

    private fun findKeyAt(x: Float, y: Float): Layout.Key? {
        return keyBounds.entries.firstOrNull { it.value.contains(x, y) }?.key
    }

    private fun dispatchKey(key: Layout.Key) {
        if (key.code != 0) {
            actionListener?.onKey(key.code)
        } else {
            val char = if (isShift || isCaps) key.shiftLabel ?: key.label else key.label
            actionListener?.onText(char)
        }
    }
}