package com.codesboard.keyboard

import android.inputmethodservice.InputMethodService
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection

/**
 * Codes Board: Professional Programmer's Keyboard for Android
 * Core InputMethodService handling IME lifecycle, modifier latching,
 * and high-performance InputConnection dispatch.
 */
class CodesBoardService : InputMethodService(), CodesBoardView.OnKeyboardActionListener {

    private lateinit var keyboardView: CodesBoardView
    
    // Modifier latch states: false = off, true = latched/active
    private var isCtrlActive = false
    private var isAltActive = false
    private var isShiftActive = false
    private var isCapsLock = false

    override fun onCreateInputView(): View {
        keyboardView = CodesBoardView(this).apply {
            setOnKeyboardActionListener(this@CodesBoardService)
        }
        return keyboardView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // Reset transient modifiers when input context switches
        isCtrlActive = false
        isAltActive = false
        isShiftActive = false
        keyboardView.updateModifierStates(isCtrlActive, isAltActive, isShiftActive, isCapsLock)
    }

    override fun onText(text: String) {
        val ic: InputConnection = currentInputConnection ?: return
        
        // If Ctrl or Alt is active, convert text to key event shortcut
        if (isCtrlActive || isAltActive) {
            handleModifierShortcut(text, ic)
            return
        }
        
        // Direct commit of text token (symbols, snippets, or characters)
        ic.commitText(text, 1)
        
        // Auto-release shift if not caps locked
        if (isShiftActive && !isCapsLock) {
            isShiftActive = false
            keyboardView.updateModifierStates(isCtrlActive, isAltActive, isShiftActive, isCapsLock)
        }
    }

    override fun onKey(keyCode: Int) {
        val ic: InputConnection = currentInputConnection ?: return
        
        when (keyCode) {
            Layout.KEYCODE_CTRL -> {
                isCtrlActive = !isCtrlActive
                keyboardView.updateModifierStates(isCtrlActive, isAltActive, isShiftActive, isCapsLock)
            }
            Layout.KEYCODE_ALT -> {
                isAltActive = !isAltActive
                keyboardView.updateModifierStates(isCtrlActive, isAltActive, isShiftActive, isCapsLock)
            }
            Layout.KEYCODE_SHIFT -> {
                if (isShiftActive && !isCapsLock) {
                    isCapsLock = true
                } else if (isCapsLock) {
                    isCapsLock = false
                    isShiftActive = false
                } else {
                    isShiftActive = true
                }
                keyboardView.updateModifierStates(isCtrlActive, isAltActive, isShiftActive, isCapsLock)
            }
            Layout.KEYCODE_DELETE -> {
                ic.deleteSurroundingText(1, 0)
            }
            Layout.KEYCODE_ENTER -> {
                sendKeyChar('\n')
            }
            Layout.KEYCODE_TAB -> {
                sendDownUpKey(KeyEvent.KEYCODE_TAB, computeMetaState())
            }
            Layout.KEYCODE_ESCAPE -> {
                sendDownUpKey(KeyEvent.KEYCODE_ESCAPE, computeMetaState())
            }
            Layout.KEYCODE_ARROW_LEFT -> sendDownUpKey(KeyEvent.KEYCODE_DPAD_LEFT, computeMetaState())
            Layout.KEYCODE_ARROW_RIGHT -> sendDownUpKey(KeyEvent.KEYCODE_DPAD_RIGHT, computeMetaState())
            Layout.KEYCODE_ARROW_UP -> sendDownUpKey(KeyEvent.KEYCODE_DPAD_UP, computeMetaState())
            Layout.KEYCODE_ARROW_DOWN -> sendDownUpKey(KeyEvent.KEYCODE_DPAD_DOWN, computeMetaState())
            Layout.KEYCODE_HOME -> sendDownUpKey(KeyEvent.KEYCODE_MOVE_HOME, computeMetaState())
            Layout.KEYCODE_END -> sendDownUpKey(KeyEvent.KEYCODE_MOVE_END, computeMetaState())
            else -> {
                sendDownUpKey(keyCode, computeMetaState())
            }
        }
    }

    private fun handleModifierShortcut(text: String, ic: InputConnection) {
        val char = text.firstOrNull() ?: return
        val keyCode = KeyEvent.keyCodeFromString("KEYCODE_${char.uppercaseChar()}")
        if (keyCode != KeyEvent.KEYCODE_UNKNOWN) {
            sendDownUpKey(keyCode, computeMetaState())
        } else {
            ic.commitText(text, 1)
        }
        
        // Auto-clear transient modifier after combo execution
        isCtrlActive = false
        isAltActive = false
        keyboardView.updateModifierStates(isCtrlActive, isAltActive, isShiftActive, isCapsLock)
    }

    private fun computeMetaState(): Int {
        var meta = 0
        if (isCtrlActive) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (isAltActive) meta = meta or KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        if (isShiftActive || isCapsLock) meta = meta or KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        return meta
    }

    private fun sendDownUpKey(keyCode: Int, metaState: Int) {
        val ic: InputConnection = currentInputConnection ?: return
        val now = SystemClock.uptimeMillis()
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0, metaState))
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0, metaState))
    }
}