package com.codesboard.keyboard

/**
 * Codes Board layout definitions:
 * Key codes, row matrices, and layer definitions.
 */
object Layout {

    const val KEYCODE_CTRL = -1001
    const val KEYCODE_ALT = -1002
    const val KEYCODE_SHIFT = -1003
    const val KEYCODE_DELETE = -1004
    const val KEYCODE_ENTER = -1005
    const val KEYCODE_TAB = -1006
    const val KEYCODE_ESCAPE = -1007
    const val KEYCODE_ARROW_LEFT = -1008
    const val KEYCODE_ARROW_RIGHT = -1009
    const val KEYCODE_ARROW_UP = -1010
    const val KEYCODE_ARROW_DOWN = -1011
    const val KEYCODE_HOME = -1012
    const val KEYCODE_END = -1013
    const val KEYCODE_SWITCH_LAYER = -1014

    enum class Layer {
        ALPHA,
        SYMBOLS_CODE,
        NUMPAD_MATH,
        NAV_FUNC
    }

    data class Key(
        val label: String,
        val shiftLabel: String? = null,
        val subLabel: String? = null,
        val code: Int = 0,
        val weight: Float = 1.0f,
        val isSpecial: Boolean = false
    )

    data class Row(val keys: List<Key>)

    // Persistent top programmer row: Esc, Tab, Arrow keys, Ctrl, Alt, Brackets
    val PROGRAMMER_TOP_ROW = Row(listOf(
        Key(label = "ESC", code = KEYCODE_ESCAPE, weight = 1.2f, isSpecial = true),
        Key(label = "TAB", code = KEYCODE_TAB, weight = 1.2f, isSpecial = true),
        Key(label = "CTRL", code = KEYCODE_CTRL, weight = 1.2f, isSpecial = true),
        Key(label = "ALT", code = KEYCODE_ALT, weight = 1.2f, isSpecial = true),
        Key(label = "{", shiftLabel = "}"),
        Key(label = "(", shiftLabel = ")"),
        Key(label = "[", shiftLabel = "]"),
        Key(label = "←", code = KEYCODE_ARROW_LEFT, weight = 1.0f, isSpecial = true),
        Key(label = "→", code = KEYCODE_ARROW_RIGHT, weight = 1.0f, isSpecial = true),
        Key(label = "DEL", code = KEYCODE_DELETE, weight = 1.3f, isSpecial = true)
    ))

    val ALPHA_ROWS = listOf(
        PROGRAMMER_TOP_ROW,
        Row(listOf(
            Key(label = "q", shiftLabel = "Q", subLabel = "1"),
            Key(label = "w", shiftLabel = "W", subLabel = "2"),
            Key(label = "e", shiftLabel = "E", subLabel = "3"),
            Key(label = "r", shiftLabel = "R", subLabel = "4"),
            Key(label = "t", shiftLabel = "T", subLabel = "5"),
            Key(label = "y", shiftLabel = "Y", subLabel = "6"),
            Key(label = "u", shiftLabel = "U", subLabel = "7"),
            Key(label = "i", shiftLabel = "I", subLabel = "8"),
            Key(label = "o", shiftLabel = "O", subLabel = "9"),
            Key(label = "p", shiftLabel = "P", subLabel = "0")
        )),
        Row(listOf(
            Key(label = "a", shiftLabel = "A", subLabel = "@"),
            Key(label = "s", shiftLabel = "S", subLabel = "#"),
            Key(label = "d", shiftLabel = "D", subLabel = "$"),
            Key(label = "f", shiftLabel = "F", subLabel = "%"),
            Key(label = "g", shiftLabel = "G", subLabel = "&"),
            Key(label = "h", shiftLabel = "H", subLabel = "*"),
            Key(label = "j", shiftLabel = "J", subLabel = "-"),
            Key(label = "k", shiftLabel = "K", subLabel = "+"),
            Key(label = "l", shiftLabel = "L", subLabel = "=")
        )),
        Row(listOf(
            Key(label = "⇧", code = KEYCODE_SHIFT, weight = 1.5f, isSpecial = true),
            Key(label = "z", shiftLabel = "Z", subLabel = "_"),
            Key(label = "x", shiftLabel = "X", subLabel = "/"),
            Key(label = "c", shiftLabel = "C", subLabel = "\\"),
            Key(label = "v", shiftLabel = "V", subLabel = "|"),
            Key(label = "b", shiftLabel = "B", subLabel = "<"),
            Key(label = "n", shiftLabel = "N", subLabel = ">"),
            Key(label = "m", shiftLabel = "M", subLabel = ";"),
            Key(label = "⌫", code = KEYCODE_DELETE, weight = 1.5f, isSpecial = true)
        )),
        Row(listOf(
            Key(label = "?123", code = KEYCODE_SWITCH_LAYER, weight = 1.4f, isSpecial = true),
            Key(label = "/", subLabel = "\\"),
            Key(label = ";", subLabel = ":"),
            Key(label = " ", weight = 3.5f),
            Key(label = ".", subLabel = ","),
            Key(label = "=", subLabel = "=="),
            Key(label = "⏎", code = KEYCODE_ENTER, weight = 1.5f, isSpecial = true)
        ))
    )

    fun getRows(layer: Layer): List<Row> = when (layer) {
        Layer.ALPHA -> ALPHA_ROWS
        Layer.SYMBOLS_CODE -> listOf(
            PROGRAMMER_TOP_ROW,
            Row(listOf(
                Key("!"), Key("@"), Key("#"), Key("$"), Key("%"),
                Key("^"), Key("&"), Key("*"), Key("("), Key(")")
            )),
            Row(listOf(
                Key("~"), Key("`"), Key("|"), Key("\\"), Key("{"),
                Key("}"), Key("["), Key("]"), Key("<"), Key(">")
            )),
            Row(listOf(
                Key("=="), Key("!="), Key("&&"), Key("||"), Key("=>"),
                Key("->"), Key("++"), Key("--"), Key("+="), Key("-=")
            )),
            Row(listOf(
                Key("ABC", code = KEYCODE_SWITCH_LAYER, weight = 1.5f, isSpecial = true),
                Key("""), Key("'"), Key(" ", weight = 3.0f), Key(":"), Key(";"),
                Key("⏎", code = KEYCODE_ENTER, weight = 1.5f, isSpecial = true)
            ))
        )
        Layer.NUMPAD_MATH -> listOf(
            PROGRAMMER_TOP_ROW,
            Row(listOf(Key("7"), Key("8"), Key("9"), Key("/"), Key("^"))),
            Row(listOf(Key("4"), Key("5"), Key("6"), Key("*"), Key("%"))),
            Row(listOf(Key("1"), Key("2"), Key("3"), Key("-"), Key("="))),
            Row(listOf(Key("ABC", code = KEYCODE_SWITCH_LAYER, isSpecial = true), Key("0"), Key("."), Key("+"), Key("⏎", code = KEYCODE_ENTER, isSpecial = true)))
        )
        Layer.NAV_FUNC -> listOf(
            PROGRAMMER_TOP_ROW,
            Row(listOf(Key("F1"), Key("F2"), Key("F3"), Key("F4"), Key("F5"), Key("F6"))),
            Row(listOf(Key("F7"), Key("F8"), Key("F9"), Key("F10"), Key("F11"), Key("F12"))),
            Row(listOf(Key("HOME", code = KEYCODE_HOME), Key("END", code = KEYCODE_END), Key("PGUP"), Key("PGDN"), Key("INS"))),
            Row(listOf(Key("ABC", code = KEYCODE_SWITCH_LAYER, isSpecial = true), Key("←"), Key("↑"), Key("↓"), Key("→"), Key("⏎", code = KEYCODE_ENTER, isSpecial = true)))
        )
    }
}