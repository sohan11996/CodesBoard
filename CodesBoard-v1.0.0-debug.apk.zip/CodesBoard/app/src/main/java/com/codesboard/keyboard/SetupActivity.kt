package com.codesboard.keyboard

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Onboarding and setup wizard for Codes Board.
 * Checks whether Codes Board is enabled in Android Settings and selected as active IME.
 */
class SetupActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var btnEnable: Button
    private lateinit var btnSelect: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        statusText = findViewById(R.id.text_status)
        btnEnable = findViewById(R.id.btn_enable_ime)
        btnSelect = findViewById(R.id.btn_select_ime)

        btnEnable.setOnClickListener {
            // Direct user to Android system keyboard settings
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        btnSelect.setOnClickListener {
            // Open system input method picker dialog
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
    }

    override fun onResume() {
        super.onResume()
        updateSetupState()
    }

    private fun updateSetupState() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabledMethods = imm.enabledInputMethodList
        val myPackage = packageName

        val isEnabled = enabledMethods.any { it.packageName == myPackage }
        val currentIme = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        val isSelected = currentIme != null && currentIme.contains(myPackage)

        when {
            !isEnabled -> {
                statusText.text = "Step 1: Enable Codes Board in Android Settings"
                btnEnable.isEnabled = true
                btnSelect.isEnabled = false
            }
            !isSelected -> {
                statusText.text = "Step 2: Select Codes Board as current keyboard"
                btnEnable.isEnabled = false
                btnSelect.isEnabled = true
            }
            else -> {
                statusText.text = "Codes Board is active! You can now code in Termux, Acode, or any editor."
                btnEnable.isEnabled = false
                btnSelect.isEnabled = false
            }
        }
    }
}